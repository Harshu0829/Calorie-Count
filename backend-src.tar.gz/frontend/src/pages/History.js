import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { FaCalendarAlt, FaFileExport, FaChevronLeft, FaChevronRight } from 'react-icons/fa';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import BottomNavigation from '../components/BottomNavigation';
import './History.css';

const History = () => {
  const [meals, setMeals] = useState([]);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [loading, setLoading] = useState(true);
  const [dailyCalories, setDailyCalories] = useState({});
  const { user } = useAuth();

  const currentMonth = selectedDate.getMonth();
  const currentYear = selectedDate.getFullYear();
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();


  // Helper to get YYYY-MM-DD in local time
  const getLocalDateKey = (date) => {
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const formatManualMeal = (meal) => ({
    ...meal,
    isManual: true,
    totalCalories: meal.calories || 0,
    totalProtein: meal.protein || 0,
    totalCarbs: meal.carbs || 0,
    totalFat: meal.fat || 0,
    foods: [{
      foodName: meal.description,
      quantity: meal.portion,
      calories: meal.calories || 0,
      protein: meal.protein || 0,
      carbs: meal.carbs || 0,
      fat: meal.fat || 0
    }]
  });

  const fetchMonthlyMeals = useCallback(async () => {
    try {
      setLoading(true);
      const [trackedResponse, manualResponse] = await Promise.all([
        api.get('/meals').catch(() => ({ data: { meals: [] } })),
        api.get('/manual-meals').catch(() => ({ data: { manualMeals: [] } }))
      ]);

      const trackedMeals = trackedResponse.data.meals || [];
      const manualMeals = manualResponse.data.manualMeals?.map(formatManualMeal) || [];
      const allMeals = [...trackedMeals, ...manualMeals];

      // Filter meals for current month (using local time boundaries)
      const mealsData = allMeals.filter(meal => {
        const mealDate = new Date(meal.date);
        return mealDate.getMonth() === currentMonth && mealDate.getFullYear() === currentYear;
      });

      // Group meals by date using local date key
      const caloriesByDate = {};
      mealsData.forEach(meal => {
        const dateKey = getLocalDateKey(meal.date);
        if (!caloriesByDate[dateKey]) {
          caloriesByDate[dateKey] = 0;
        }
        caloriesByDate[dateKey] += meal.totalCalories || 0;
      });

      setDailyCalories(caloriesByDate);
      setMeals(mealsData);
    } catch (error) {
      console.error('Error fetching monthly meals:', error);
      setDailyCalories({});
      setMeals([]);
    } finally {
      setLoading(false);
    }
  }, [currentMonth, currentYear]);

  useEffect(() => {
    fetchMonthlyMeals();
  }, [fetchMonthlyMeals]);

  const getDateMeals = (day) => {
    const targetKey = getLocalDateKey(new Date(currentYear, currentMonth, day));
    return meals.filter(meal => {
      return getLocalDateKey(meal.date) === targetKey;
    });
  };

  const getCalorieStatus = (day) => {
    const dateKey = getLocalDateKey(new Date(currentYear, currentMonth, day));
    const calories = dailyCalories[dateKey] || 0;
    const goal = user?.dailyCalorieGoal || 2000;

    if (calories === 0) return 'none';
    if (calories < goal * 0.7) return 'low';
    if (calories < goal) return 'good';
    if (calories <= goal * 1.2) return 'perfect';
    return 'over';
  };

  const prevMonth = () => {
    setSelectedDate(new Date(currentYear, currentMonth - 1, 1));
  };

  const nextMonth = () => {
    setSelectedDate(new Date(currentYear, currentMonth + 1, 1));
  };

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const [selectedDay, setSelectedDay] = useState(null);

  const selectedDayMeals = selectedDay ? getDateMeals(selectedDay) : [];

  const exportData = () => {
    const csvContent = [
      ['Date', 'Meal Type', 'Food', 'Quantity (g)', 'Calories', 'Protein (g)', 'Carbs (g)', 'Fat (g)'],
      ...meals.flatMap(meal =>
        meal.foods.map(food => [
          new Date(meal.date).toLocaleDateString(),
          meal.mealType,
          food.foodName,
          food.quantity,
          food.calories,
          food.protein,
          food.carbs,
          food.fat
        ])
      )
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `calorie-tracker-${monthNames[currentMonth]}-${currentYear}.csv`;
    a.click();
  };

  if (loading) {
    return (
      <div className="history">
        <div className="container">
          <div className="loading">
            <div className="spinner"></div>
            <p>Loading history...</p>
          </div>
        </div>
        <BottomNavigation />
      </div>
    );
  }

  return (
    <div className="history">
      <div className="container">
        <motion.header
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="history-header"
        >
          <h1>
            <FaCalendarAlt /> Meal History
          </h1>
          <button onClick={exportData} className="btn btn-secondary export-btn">
            <FaFileExport /> Export CSV
          </button>
        </motion.header>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="calendar-container card"
        >
          <div className="calendar-header">
            <button onClick={prevMonth} className="calendar-nav-btn">
              <FaChevronLeft />
            </button>
            <h2>
              {monthNames[currentMonth]} {currentYear}
            </h2>
            <button onClick={nextMonth} className="calendar-nav-btn">
              <FaChevronRight />
            </button>
          </div>

          <div className="calendar-grid-wrapper">
            <div className="calendar-grid">
              {weekDays.map(day => (
                <div key={day} className="calendar-weekday">
                  {day}
                </div>
              ))}

              {Array.from({ length: firstDayOfMonth }).map((_, idx) => (
                <div key={`empty-${idx}`} className="calendar-day empty" />
              ))}

              {Array.from({ length: daysInMonth }).map((_, idx) => {
                const day = idx + 1;
                const status = getCalorieStatus(day);
                const dateKey = getLocalDateKey(new Date(currentYear, currentMonth, day));
                const calories = dailyCalories[dateKey] || 0;
                const isSelected = selectedDay === day;

                return (
                  <motion.div
                    key={day}
                    className={`calendar-day ${status} ${isSelected ? 'selected' : ''}`}
                    onClick={() => setSelectedDay(day)}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: idx * 0.01 }}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <div className="day-number">{day}</div>
                    {calories > 0 && (
                      <div className="day-calories">{Math.round(calories)}</div>
                    )}
                  </motion.div>
                );
              })}
            </div>
          </div>

          <div className="calendar-legend">
            <div className="legend-item">
              <div className="legend-color none"></div>
              <span>No data</span>
            </div>
            <div className="legend-item">
              <div className="legend-color low"></div>
              <span>Under 70%</span>
            </div>
            <div className="legend-item">
              <div className="legend-color good"></div>
              <span>70-100%</span>
            </div>
            <div className="legend-item">
              <div className="legend-color perfect"></div>
              <span>100-120%</span>
            </div>
            <div className="legend-item">
              <div className="legend-color over"></div>
              <span>Over 120%</span>
            </div>
          </div>
        </motion.div>

        {selectedDay && selectedDayMeals.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="selected-day-meals card"
          >
            <h2>
              {monthNames[currentMonth]} {selectedDay}, {currentYear}
            </h2>
            <div className="meals-list">
              {selectedDayMeals.map(meal => (
                <div key={meal._id} className="meal-item">
                  <div className="meal-header">
                    <div className="meal-header-title">
                      <h3>{meal.mealType.charAt(0).toUpperCase() + meal.mealType.slice(1)}</h3>
                      {meal.isManual && <span className="manual-tag small">Manual Entry</span>}
                    </div>
                    <span className="meal-time">
                      {new Date(meal.date).toLocaleTimeString('en-US', {
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </span>
                  </div>
                  <div className="meal-foods">
                    {meal.foods.map((food, idx) => (
                      <div key={idx} className="food-item">
                        <span className="food-name">{food.foodName}</span>
                        <span className="food-details">
                          {food.quantity}g • {Math.round(food.calories)} kcal
                        </span>
                      </div>
                    ))}
                  </div>
                  <div className="meal-total">
                    Total: {Math.round(meal.totalCalories)} kcal
                    {' • '}
                    P: {Math.round(meal.totalProtein)}g • C: {Math.round(meal.totalCarbs)}g • F: {Math.round(meal.totalFat)}g
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </div>
      <BottomNavigation />
    </div>
  );
};

export default History;

